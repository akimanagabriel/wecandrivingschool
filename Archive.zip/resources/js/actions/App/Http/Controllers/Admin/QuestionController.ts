import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\QuestionController::index
* @see app/Http/Controllers/Admin/QuestionController.php:17
* @route '/admin/questions'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/questions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\QuestionController::index
* @see app/Http/Controllers/Admin/QuestionController.php:17
* @route '/admin/questions'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QuestionController::index
* @see app/Http/Controllers/Admin/QuestionController.php:17
* @route '/admin/questions'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\QuestionController::index
* @see app/Http/Controllers/Admin/QuestionController.php:17
* @route '/admin/questions'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\QuestionController::index
* @see app/Http/Controllers/Admin/QuestionController.php:17
* @route '/admin/questions'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\QuestionController::index
* @see app/Http/Controllers/Admin/QuestionController.php:17
* @route '/admin/questions'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\QuestionController::index
* @see app/Http/Controllers/Admin/QuestionController.php:17
* @route '/admin/questions'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\QuestionController::create
* @see app/Http/Controllers/Admin/QuestionController.php:41
* @route '/admin/questions/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/questions/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\QuestionController::create
* @see app/Http/Controllers/Admin/QuestionController.php:41
* @route '/admin/questions/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QuestionController::create
* @see app/Http/Controllers/Admin/QuestionController.php:41
* @route '/admin/questions/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\QuestionController::create
* @see app/Http/Controllers/Admin/QuestionController.php:41
* @route '/admin/questions/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\QuestionController::create
* @see app/Http/Controllers/Admin/QuestionController.php:41
* @route '/admin/questions/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\QuestionController::create
* @see app/Http/Controllers/Admin/QuestionController.php:41
* @route '/admin/questions/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\QuestionController::create
* @see app/Http/Controllers/Admin/QuestionController.php:41
* @route '/admin/questions/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\Admin\QuestionController::store
* @see app/Http/Controllers/Admin/QuestionController.php:48
* @route '/admin/questions'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/questions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\QuestionController::store
* @see app/Http/Controllers/Admin/QuestionController.php:48
* @route '/admin/questions'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QuestionController::store
* @see app/Http/Controllers/Admin/QuestionController.php:48
* @route '/admin/questions'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QuestionController::store
* @see app/Http/Controllers/Admin/QuestionController.php:48
* @route '/admin/questions'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QuestionController::store
* @see app/Http/Controllers/Admin/QuestionController.php:48
* @route '/admin/questions'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Admin\QuestionController::edit
* @see app/Http/Controllers/Admin/QuestionController.php:79
* @route '/admin/questions/{question}/edit'
*/
export const edit = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/questions/{question}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\QuestionController::edit
* @see app/Http/Controllers/Admin/QuestionController.php:79
* @route '/admin/questions/{question}/edit'
*/
edit.url = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { question: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { question: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            question: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        question: typeof args.question === 'object'
        ? args.question.id
        : args.question,
    }

    return edit.definition.url
            .replace('{question}', parsedArgs.question.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QuestionController::edit
* @see app/Http/Controllers/Admin/QuestionController.php:79
* @route '/admin/questions/{question}/edit'
*/
edit.get = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\QuestionController::edit
* @see app/Http/Controllers/Admin/QuestionController.php:79
* @route '/admin/questions/{question}/edit'
*/
edit.head = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\QuestionController::edit
* @see app/Http/Controllers/Admin/QuestionController.php:79
* @route '/admin/questions/{question}/edit'
*/
const editForm = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\QuestionController::edit
* @see app/Http/Controllers/Admin/QuestionController.php:79
* @route '/admin/questions/{question}/edit'
*/
editForm.get = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\QuestionController::edit
* @see app/Http/Controllers/Admin/QuestionController.php:79
* @route '/admin/questions/{question}/edit'
*/
editForm.head = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\Admin\QuestionController::update
* @see app/Http/Controllers/Admin/QuestionController.php:87
* @route '/admin/questions/{question}'
*/
const update8dd40d2fc82f24c6813a125f02424b5e = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update8dd40d2fc82f24c6813a125f02424b5e.url(args, options),
    method: 'put',
})

update8dd40d2fc82f24c6813a125f02424b5e.definition = {
    methods: ["put"],
    url: '/admin/questions/{question}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\QuestionController::update
* @see app/Http/Controllers/Admin/QuestionController.php:87
* @route '/admin/questions/{question}'
*/
update8dd40d2fc82f24c6813a125f02424b5e.url = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { question: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { question: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            question: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        question: typeof args.question === 'object'
        ? args.question.id
        : args.question,
    }

    return update8dd40d2fc82f24c6813a125f02424b5e.definition.url
            .replace('{question}', parsedArgs.question.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QuestionController::update
* @see app/Http/Controllers/Admin/QuestionController.php:87
* @route '/admin/questions/{question}'
*/
update8dd40d2fc82f24c6813a125f02424b5e.put = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update8dd40d2fc82f24c6813a125f02424b5e.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Admin\QuestionController::update
* @see app/Http/Controllers/Admin/QuestionController.php:87
* @route '/admin/questions/{question}'
*/
const update8dd40d2fc82f24c6813a125f02424b5eForm = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update8dd40d2fc82f24c6813a125f02424b5e.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QuestionController::update
* @see app/Http/Controllers/Admin/QuestionController.php:87
* @route '/admin/questions/{question}'
*/
update8dd40d2fc82f24c6813a125f02424b5eForm.put = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update8dd40d2fc82f24c6813a125f02424b5e.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update8dd40d2fc82f24c6813a125f02424b5e.form = update8dd40d2fc82f24c6813a125f02424b5eForm
/**
* @see \App\Http\Controllers\Admin\QuestionController::update
* @see app/Http/Controllers/Admin/QuestionController.php:87
* @route '/admin/questions/{question}'
*/
const update8dd40d2fc82f24c6813a125f02424b5e = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update8dd40d2fc82f24c6813a125f02424b5e.url(args, options),
    method: 'post',
})

update8dd40d2fc82f24c6813a125f02424b5e.definition = {
    methods: ["post"],
    url: '/admin/questions/{question}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\QuestionController::update
* @see app/Http/Controllers/Admin/QuestionController.php:87
* @route '/admin/questions/{question}'
*/
update8dd40d2fc82f24c6813a125f02424b5e.url = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { question: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { question: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            question: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        question: typeof args.question === 'object'
        ? args.question.id
        : args.question,
    }

    return update8dd40d2fc82f24c6813a125f02424b5e.definition.url
            .replace('{question}', parsedArgs.question.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QuestionController::update
* @see app/Http/Controllers/Admin/QuestionController.php:87
* @route '/admin/questions/{question}'
*/
update8dd40d2fc82f24c6813a125f02424b5e.post = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update8dd40d2fc82f24c6813a125f02424b5e.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QuestionController::update
* @see app/Http/Controllers/Admin/QuestionController.php:87
* @route '/admin/questions/{question}'
*/
const update8dd40d2fc82f24c6813a125f02424b5eForm = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update8dd40d2fc82f24c6813a125f02424b5e.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QuestionController::update
* @see app/Http/Controllers/Admin/QuestionController.php:87
* @route '/admin/questions/{question}'
*/
update8dd40d2fc82f24c6813a125f02424b5eForm.post = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update8dd40d2fc82f24c6813a125f02424b5e.url(args, options),
    method: 'post',
})

update8dd40d2fc82f24c6813a125f02424b5e.form = update8dd40d2fc82f24c6813a125f02424b5eForm

export const update = {
    '/admin/questions/{question}': update8dd40d2fc82f24c6813a125f02424b5e,
    '/admin/questions/{question}': update8dd40d2fc82f24c6813a125f02424b5e,
}

/**
* @see \App\Http\Controllers\Admin\QuestionController::destroy
* @see app/Http/Controllers/Admin/QuestionController.php:129
* @route '/admin/questions/{question}'
*/
export const destroy = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/questions/{question}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\QuestionController::destroy
* @see app/Http/Controllers/Admin/QuestionController.php:129
* @route '/admin/questions/{question}'
*/
destroy.url = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { question: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { question: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            question: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        question: typeof args.question === 'object'
        ? args.question.id
        : args.question,
    }

    return destroy.definition.url
            .replace('{question}', parsedArgs.question.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QuestionController::destroy
* @see app/Http/Controllers/Admin/QuestionController.php:129
* @route '/admin/questions/{question}'
*/
destroy.delete = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Admin\QuestionController::destroy
* @see app/Http/Controllers/Admin/QuestionController.php:129
* @route '/admin/questions/{question}'
*/
const destroyForm = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QuestionController::destroy
* @see app/Http/Controllers/Admin/QuestionController.php:129
* @route '/admin/questions/{question}'
*/
destroyForm.delete = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const QuestionController = { index, create, store, edit, update, destroy }

export default QuestionController