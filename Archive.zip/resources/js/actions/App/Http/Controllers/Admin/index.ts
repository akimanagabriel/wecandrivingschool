import DashboardController from './DashboardController'
import QuestionController from './QuestionController'
import UserController from './UserController'
import PaymentController from './PaymentController'

const Admin = {
    DashboardController: Object.assign(DashboardController, DashboardController),
    QuestionController: Object.assign(QuestionController, QuestionController),
    UserController: Object.assign(UserController, UserController),
    PaymentController: Object.assign(PaymentController, PaymentController),
}

export default Admin