import Settings from './Settings'
import StudentDashboardController from './StudentDashboardController'
import PaymentController from './PaymentController'
import QuizController from './QuizController'
import Admin from './Admin'

const Controllers = {
    Settings: Object.assign(Settings, Settings),
    StudentDashboardController: Object.assign(StudentDashboardController, StudentDashboardController),
    PaymentController: Object.assign(PaymentController, PaymentController),
    QuizController: Object.assign(QuizController, QuizController),
    Admin: Object.assign(Admin, Admin),
}

export default Controllers