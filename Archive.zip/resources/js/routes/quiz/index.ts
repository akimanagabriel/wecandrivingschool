import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\QuizController::start
* @see app/Http/Controllers/QuizController.php:18
* @route '/quiz/start'
*/
export const start = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(options),
    method: 'post',
})

start.definition = {
    methods: ["post"],
    url: '/quiz/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\QuizController::start
* @see app/Http/Controllers/QuizController.php:18
* @route '/quiz/start'
*/
start.url = (options?: RouteQueryOptions) => {
    return start.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\QuizController::start
* @see app/Http/Controllers/QuizController.php:18
* @route '/quiz/start'
*/
start.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\QuizController::start
* @see app/Http/Controllers/QuizController.php:18
* @route '/quiz/start'
*/
const startForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: start.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\QuizController::start
* @see app/Http/Controllers/QuizController.php:18
* @route '/quiz/start'
*/
startForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: start.url(options),
    method: 'post',
})

start.form = startForm

/**
* @see \App\Http\Controllers\QuizController::take
* @see app/Http/Controllers/QuizController.php:62
* @route '/quiz/{attempt}'
*/
export const take = (args: { attempt: number | { id: number } } | [attempt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: take.url(args, options),
    method: 'get',
})

take.definition = {
    methods: ["get","head"],
    url: '/quiz/{attempt}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\QuizController::take
* @see app/Http/Controllers/QuizController.php:62
* @route '/quiz/{attempt}'
*/
take.url = (args: { attempt: number | { id: number } } | [attempt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { attempt: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { attempt: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            attempt: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        attempt: typeof args.attempt === 'object'
        ? args.attempt.id
        : args.attempt,
    }

    return take.definition.url
            .replace('{attempt}', parsedArgs.attempt.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\QuizController::take
* @see app/Http/Controllers/QuizController.php:62
* @route '/quiz/{attempt}'
*/
take.get = (args: { attempt: number | { id: number } } | [attempt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: take.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\QuizController::take
* @see app/Http/Controllers/QuizController.php:62
* @route '/quiz/{attempt}'
*/
take.head = (args: { attempt: number | { id: number } } | [attempt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: take.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\QuizController::take
* @see app/Http/Controllers/QuizController.php:62
* @route '/quiz/{attempt}'
*/
const takeForm = (args: { attempt: number | { id: number } } | [attempt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: take.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\QuizController::take
* @see app/Http/Controllers/QuizController.php:62
* @route '/quiz/{attempt}'
*/
takeForm.get = (args: { attempt: number | { id: number } } | [attempt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: take.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\QuizController::take
* @see app/Http/Controllers/QuizController.php:62
* @route '/quiz/{attempt}'
*/
takeForm.head = (args: { attempt: number | { id: number } } | [attempt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: take.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

take.form = takeForm

/**
* @see \App\Http\Controllers\QuizController::answer
* @see app/Http/Controllers/QuizController.php:104
* @route '/quiz/{attempt}/answer'
*/
export const answer = (args: { attempt: number | { id: number } } | [attempt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: answer.url(args, options),
    method: 'post',
})

answer.definition = {
    methods: ["post"],
    url: '/quiz/{attempt}/answer',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\QuizController::answer
* @see app/Http/Controllers/QuizController.php:104
* @route '/quiz/{attempt}/answer'
*/
answer.url = (args: { attempt: number | { id: number } } | [attempt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { attempt: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { attempt: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            attempt: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        attempt: typeof args.attempt === 'object'
        ? args.attempt.id
        : args.attempt,
    }

    return answer.definition.url
            .replace('{attempt}', parsedArgs.attempt.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\QuizController::answer
* @see app/Http/Controllers/QuizController.php:104
* @route '/quiz/{attempt}/answer'
*/
answer.post = (args: { attempt: number | { id: number } } | [attempt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: answer.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\QuizController::answer
* @see app/Http/Controllers/QuizController.php:104
* @route '/quiz/{attempt}/answer'
*/
const answerForm = (args: { attempt: number | { id: number } } | [attempt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: answer.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\QuizController::answer
* @see app/Http/Controllers/QuizController.php:104
* @route '/quiz/{attempt}/answer'
*/
answerForm.post = (args: { attempt: number | { id: number } } | [attempt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: answer.url(args, options),
    method: 'post',
})

answer.form = answerForm

/**
* @see \App\Http\Controllers\QuizController::submit
* @see app/Http/Controllers/QuizController.php:141
* @route '/quiz/{attempt}/submit'
*/
export const submit = (args: { attempt: number | { id: number } } | [attempt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(args, options),
    method: 'post',
})

submit.definition = {
    methods: ["post"],
    url: '/quiz/{attempt}/submit',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\QuizController::submit
* @see app/Http/Controllers/QuizController.php:141
* @route '/quiz/{attempt}/submit'
*/
submit.url = (args: { attempt: number | { id: number } } | [attempt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { attempt: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { attempt: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            attempt: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        attempt: typeof args.attempt === 'object'
        ? args.attempt.id
        : args.attempt,
    }

    return submit.definition.url
            .replace('{attempt}', parsedArgs.attempt.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\QuizController::submit
* @see app/Http/Controllers/QuizController.php:141
* @route '/quiz/{attempt}/submit'
*/
submit.post = (args: { attempt: number | { id: number } } | [attempt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\QuizController::submit
* @see app/Http/Controllers/QuizController.php:141
* @route '/quiz/{attempt}/submit'
*/
const submitForm = (args: { attempt: number | { id: number } } | [attempt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submit.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\QuizController::submit
* @see app/Http/Controllers/QuizController.php:141
* @route '/quiz/{attempt}/submit'
*/
submitForm.post = (args: { attempt: number | { id: number } } | [attempt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submit.url(args, options),
    method: 'post',
})

submit.form = submitForm

/**
* @see \App\Http\Controllers\QuizController::results
* @see app/Http/Controllers/QuizController.php:155
* @route '/quiz/{attempt}/results'
*/
export const results = (args: { attempt: number | { id: number } } | [attempt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: results.url(args, options),
    method: 'get',
})

results.definition = {
    methods: ["get","head"],
    url: '/quiz/{attempt}/results',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\QuizController::results
* @see app/Http/Controllers/QuizController.php:155
* @route '/quiz/{attempt}/results'
*/
results.url = (args: { attempt: number | { id: number } } | [attempt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { attempt: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { attempt: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            attempt: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        attempt: typeof args.attempt === 'object'
        ? args.attempt.id
        : args.attempt,
    }

    return results.definition.url
            .replace('{attempt}', parsedArgs.attempt.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\QuizController::results
* @see app/Http/Controllers/QuizController.php:155
* @route '/quiz/{attempt}/results'
*/
results.get = (args: { attempt: number | { id: number } } | [attempt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: results.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\QuizController::results
* @see app/Http/Controllers/QuizController.php:155
* @route '/quiz/{attempt}/results'
*/
results.head = (args: { attempt: number | { id: number } } | [attempt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: results.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\QuizController::results
* @see app/Http/Controllers/QuizController.php:155
* @route '/quiz/{attempt}/results'
*/
const resultsForm = (args: { attempt: number | { id: number } } | [attempt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: results.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\QuizController::results
* @see app/Http/Controllers/QuizController.php:155
* @route '/quiz/{attempt}/results'
*/
resultsForm.get = (args: { attempt: number | { id: number } } | [attempt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: results.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\QuizController::results
* @see app/Http/Controllers/QuizController.php:155
* @route '/quiz/{attempt}/results'
*/
resultsForm.head = (args: { attempt: number | { id: number } } | [attempt: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: results.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

results.form = resultsForm

const quiz = {
    start: Object.assign(start, start),
    take: Object.assign(take, take),
    answer: Object.assign(answer, answer),
    submit: Object.assign(submit, submit),
    results: Object.assign(results, results),
}

export default quiz