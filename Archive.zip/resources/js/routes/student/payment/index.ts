import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\PaymentController::momo
* @see app/Http/Controllers/PaymentController.php:34
* @route '/student/payment/momo'
*/
export const momo = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: momo.url(options),
    method: 'post',
})

momo.definition = {
    methods: ["post"],
    url: '/student/payment/momo',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PaymentController::momo
* @see app/Http/Controllers/PaymentController.php:34
* @route '/student/payment/momo'
*/
momo.url = (options?: RouteQueryOptions) => {
    return momo.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaymentController::momo
* @see app/Http/Controllers/PaymentController.php:34
* @route '/student/payment/momo'
*/
momo.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: momo.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PaymentController::momo
* @see app/Http/Controllers/PaymentController.php:34
* @route '/student/payment/momo'
*/
const momoForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: momo.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PaymentController::momo
* @see app/Http/Controllers/PaymentController.php:34
* @route '/student/payment/momo'
*/
momoForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: momo.url(options),
    method: 'post',
})

momo.form = momoForm

/**
* @see \App\Http\Controllers\PaymentController::success
* @see app/Http/Controllers/PaymentController.php:107
* @route '/student/payment/success/{payment}'
*/
export const success = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: success.url(args, options),
    method: 'get',
})

success.definition = {
    methods: ["get","head"],
    url: '/student/payment/success/{payment}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PaymentController::success
* @see app/Http/Controllers/PaymentController.php:107
* @route '/student/payment/success/{payment}'
*/
success.url = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { payment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { payment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            payment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        payment: typeof args.payment === 'object'
        ? args.payment.id
        : args.payment,
    }

    return success.definition.url
            .replace('{payment}', parsedArgs.payment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaymentController::success
* @see app/Http/Controllers/PaymentController.php:107
* @route '/student/payment/success/{payment}'
*/
success.get = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: success.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PaymentController::success
* @see app/Http/Controllers/PaymentController.php:107
* @route '/student/payment/success/{payment}'
*/
success.head = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: success.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\PaymentController::success
* @see app/Http/Controllers/PaymentController.php:107
* @route '/student/payment/success/{payment}'
*/
const successForm = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: success.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PaymentController::success
* @see app/Http/Controllers/PaymentController.php:107
* @route '/student/payment/success/{payment}'
*/
successForm.get = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: success.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\PaymentController::success
* @see app/Http/Controllers/PaymentController.php:107
* @route '/student/payment/success/{payment}'
*/
successForm.head = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: success.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

success.form = successForm

const payment = {
    momo: Object.assign(momo, momo),
    success: Object.assign(success, success),
}

export default payment