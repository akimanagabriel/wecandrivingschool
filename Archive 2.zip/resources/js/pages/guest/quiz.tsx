// resources/js/pages/guest/quiz.tsx
import { useState, useEffect } from 'react';
import { router } from '@inertiajs/react';
import { toast } from 'sonner';

interface Question {
    id: number;
    question_text: string;
    image_path: string | null;
    category: string;
    options: Array<{ id: number; option_text: string }>;
}

interface Props {
    token: string;
    attempt: {
        id: number;
        remainingSeconds: number;
        totalQuestions: number;
    };
    questions: Question[];
    savedAnswers: Record<number, number>;
}

export default function GuestQuiz({
    token,
    attempt,
    questions,
    savedAnswers,
}: Props) {
    const [answers, setAnswers] =
        useState<Record<number, number>>(savedAnswers);
    const [timeLeft, setTimeLeft] = useState(attempt.remainingSeconds);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [currentQuestion, setCurrentQuestion] = useState(0);
    const [saving, setSaving] = useState<number | null>(null);

    useEffect(() => {
        if (timeLeft <= 0 && !isSubmitting) {
            handleAutoSubmit();
            return;
        }

        const timer = setInterval(() => {
            setTimeLeft((prev) => {
                if (prev <= 1) {
                    clearInterval(timer);
                    return 0;
                }
                return prev - 1;
            });
        }, 1000);

        return () => clearInterval(timer);
    }, [timeLeft]);

    const handleAutoSubmit = () => {
        if (isSubmitting) return;
        toast.warning('Time is up! Submitting your quiz...');
        handleSubmit();
    };

    const saveAnswer = (questionId: number, optionId: number) => {
        setSaving(questionId);

        // Use Inertia router which handles CSRF automatically
        router.post(
            `/shared/quiz/${token}/save-answer/${attempt.id}`,
            {
                question_id: questionId,
                option_id: optionId,
            },
            {
                preserveScroll: true,
                preserveState: true,
                onSuccess: () => {
                    // Answer saved successfully - no toast needed
                },
                onError: (errors) => {
                    console.error('Save answer error:', errors);
                    toast.error('Failed to save answer. Please try again.');
                },
                onFinish: () => {
                    setSaving(null);
                },
            },
        );
    };

    const handleAnswerSelect = (questionId: number, optionId: number) => {
        const newAnswers = { ...answers, [questionId]: optionId };
        setAnswers(newAnswers);

        // Save the answer
        saveAnswer(questionId, optionId);
    };

    const handleSubmit = () => {
        if (isSubmitting) return;
        setIsSubmitting(true);

        router.post(
            `/shared/quiz/${token}/submit/${attempt.id}`,
            {
                answers: answers,
            },
            {
                preserveState: false,
                onSuccess: () => {
                    toast.success('Quiz submitted successfully!');
                },
                onError: (errors) => {
                    console.error('Submit error:', errors);
                    toast.error('Failed to submit quiz. Please try again.');
                    setIsSubmitting(false);
                },
            },
        );
    };

    const formatTime = (seconds: number) => {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    };

    const progress =
        (Object.keys(answers).length / attempt.totalQuestions) * 100;
    const currentQ = questions[currentQuestion];

    if (!currentQ) {
        return <div className="p-8 text-center">Loading...</div>;
    }

    return (
        <div className="min-h-screen bg-gray-50">
            {/* Header */}
            <div className="sticky top-0 z-10 bg-white shadow-md">
                <div className="mx-auto max-w-7xl px-4 py-3">
                    <div className="flex items-center justify-between">
                        <div>
                            <h2 className="text-lg font-semibold">
                                Theory Test Practice
                            </h2>
                            <p className="text-sm text-gray-500">
                                {Object.keys(answers).length} of{' '}
                                {attempt.totalQuestions} answered
                            </p>
                        </div>
                        <div className="text-right">
                            <div
                                className={`text-2xl font-bold ${timeLeft < 60 ? 'text-red-600' : 'text-indigo-600'}`}
                            >
                                {formatTime(timeLeft)}
                            </div>
                            <div className="text-xs text-gray-500">
                                Time Remaining
                            </div>
                        </div>
                    </div>
                    <div className="mt-2 h-2 overflow-hidden rounded-full bg-gray-200">
                        <div
                            className="h-full bg-indigo-600 transition-all duration-300"
                            style={{ width: `${progress}%` }}
                        />
                    </div>
                </div>
            </div>

            {/* Quiz Content */}
            <div className="mx-auto max-w-3xl px-4 py-8">
                <div className="rounded-lg bg-white p-6 shadow-md">
                    <div className="mb-6">
                        <div className="mb-4 flex items-center justify-between">
                            <span className="text-sm font-semibold text-indigo-600">
                                Question {currentQuestion + 1} of{' '}
                                {attempt.totalQuestions}
                            </span>
                            <div className="flex gap-2">
                                <button
                                    onClick={() =>
                                        setCurrentQuestion((prev) =>
                                            Math.max(0, prev - 1),
                                        )
                                    }
                                    disabled={currentQuestion === 0}
                                    className="rounded border px-3 py-1 hover:bg-gray-50 disabled:opacity-50"
                                >
                                    Previous
                                </button>
                                <button
                                    onClick={() =>
                                        setCurrentQuestion((prev) =>
                                            Math.min(
                                                attempt.totalQuestions - 1,
                                                prev + 1,
                                            ),
                                        )
                                    }
                                    disabled={
                                        currentQuestion ===
                                        attempt.totalQuestions - 1
                                    }
                                    className="rounded border px-3 py-1 hover:bg-gray-50 disabled:opacity-50"
                                >
                                    Next
                                </button>
                            </div>
                        </div>

                        <div className="mb-2">
                            <span className="rounded bg-gray-100 px-2 py-1 text-xs">
                                {currentQ.category}
                            </span>
                            {saving === currentQ.id && (
                                <span className="ml-2 text-xs text-gray-400">
                                    Saving...
                                </span>
                            )}
                        </div>

                        <h3 className="mb-4 text-lg font-medium">
                            {currentQ.question_text}
                        </h3>

                        {currentQ.image_path && (
                            <img
                                src={currentQ.image_path}
                                alt="Question illustration"
                                className="mb-4 max-h-48 w-auto rounded-lg"
                            />
                        )}

                        <div className="space-y-3">
                            {currentQ.options.map((option) => (
                                <label
                                    key={option.id}
                                    className={`flex cursor-pointer items-center rounded-lg border p-3 transition ${
                                        answers[currentQ.id] === option.id
                                            ? 'border-indigo-500 bg-indigo-50'
                                            : 'border-gray-200 hover:bg-gray-50'
                                    }`}
                                >
                                    <input
                                        type="radio"
                                        name={`question_${currentQ.id}`}
                                        value={option.id}
                                        checked={
                                            answers[currentQ.id] === option.id
                                        }
                                        onChange={() =>
                                            handleAnswerSelect(
                                                currentQ.id,
                                                option.id,
                                            )
                                        }
                                        className="mr-3"
                                    />
                                    <span className="text-gray-700">
                                        {option.option_text}
                                    </span>
                                </label>
                            ))}
                        </div>
                    </div>
                </div>

                <div className="mt-8 flex justify-center">
                    <button
                        onClick={handleSubmit}
                        disabled={isSubmitting}
                        className="rounded-lg bg-indigo-600 px-8 py-3 font-semibold text-white hover:bg-indigo-700 disabled:opacity-50"
                    >
                        {isSubmitting ? 'Submitting...' : 'Submit Quiz'}
                    </button>
                </div>
            </div>
        </div>
    );
}
