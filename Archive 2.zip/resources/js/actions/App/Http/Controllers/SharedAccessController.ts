import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SharedAccessController::access
* @see app/Http/Controllers/SharedAccessController.php:19
* @route '/shared/access/{token}'
*/
export const access = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: access.url(args, options),
    method: 'get',
})

access.definition = {
    methods: ["get","head"],
    url: '/shared/access/{token}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SharedAccessController::access
* @see app/Http/Controllers/SharedAccessController.php:19
* @route '/shared/access/{token}'
*/
access.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    if (Array.isArray(args)) {
        args = {
            token: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        token: args.token,
    }

    return access.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SharedAccessController::access
* @see app/Http/Controllers/SharedAccessController.php:19
* @route '/shared/access/{token}'
*/
access.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: access.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SharedAccessController::access
* @see app/Http/Controllers/SharedAccessController.php:19
* @route '/shared/access/{token}'
*/
access.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: access.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SharedAccessController::access
* @see app/Http/Controllers/SharedAccessController.php:19
* @route '/shared/access/{token}'
*/
const accessForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: access.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SharedAccessController::access
* @see app/Http/Controllers/SharedAccessController.php:19
* @route '/shared/access/{token}'
*/
accessForm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: access.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SharedAccessController::access
* @see app/Http/Controllers/SharedAccessController.php:19
* @route '/shared/access/{token}'
*/
accessForm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: access.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

access.form = accessForm

/**
* @see \App\Http\Controllers\SharedAccessController::startQuiz
* @see app/Http/Controllers/SharedAccessController.php:31
* @route '/shared/quiz/{token}/start'
*/
export const startQuiz = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: startQuiz.url(args, options),
    method: 'get',
})

startQuiz.definition = {
    methods: ["get","head"],
    url: '/shared/quiz/{token}/start',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SharedAccessController::startQuiz
* @see app/Http/Controllers/SharedAccessController.php:31
* @route '/shared/quiz/{token}/start'
*/
startQuiz.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    if (Array.isArray(args)) {
        args = {
            token: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        token: args.token,
    }

    return startQuiz.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SharedAccessController::startQuiz
* @see app/Http/Controllers/SharedAccessController.php:31
* @route '/shared/quiz/{token}/start'
*/
startQuiz.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: startQuiz.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SharedAccessController::startQuiz
* @see app/Http/Controllers/SharedAccessController.php:31
* @route '/shared/quiz/{token}/start'
*/
startQuiz.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: startQuiz.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SharedAccessController::startQuiz
* @see app/Http/Controllers/SharedAccessController.php:31
* @route '/shared/quiz/{token}/start'
*/
const startQuizForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: startQuiz.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SharedAccessController::startQuiz
* @see app/Http/Controllers/SharedAccessController.php:31
* @route '/shared/quiz/{token}/start'
*/
startQuizForm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: startQuiz.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SharedAccessController::startQuiz
* @see app/Http/Controllers/SharedAccessController.php:31
* @route '/shared/quiz/{token}/start'
*/
startQuizForm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: startQuiz.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

startQuiz.form = startQuizForm

/**
* @see \App\Http\Controllers\SharedAccessController::takeQuiz
* @see app/Http/Controllers/SharedAccessController.php:93
* @route '/shared/quiz/{token}/take/{attempt}'
*/
export const takeQuiz = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: takeQuiz.url(args, options),
    method: 'get',
})

takeQuiz.definition = {
    methods: ["get","head"],
    url: '/shared/quiz/{token}/take/{attempt}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SharedAccessController::takeQuiz
* @see app/Http/Controllers/SharedAccessController.php:93
* @route '/shared/quiz/{token}/take/{attempt}'
*/
takeQuiz.url = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            token: args[0],
            attempt: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        token: args.token,
        attempt: typeof args.attempt === 'object'
        ? args.attempt.id
        : args.attempt,
    }

    return takeQuiz.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace('{attempt}', parsedArgs.attempt.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SharedAccessController::takeQuiz
* @see app/Http/Controllers/SharedAccessController.php:93
* @route '/shared/quiz/{token}/take/{attempt}'
*/
takeQuiz.get = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: takeQuiz.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SharedAccessController::takeQuiz
* @see app/Http/Controllers/SharedAccessController.php:93
* @route '/shared/quiz/{token}/take/{attempt}'
*/
takeQuiz.head = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: takeQuiz.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SharedAccessController::takeQuiz
* @see app/Http/Controllers/SharedAccessController.php:93
* @route '/shared/quiz/{token}/take/{attempt}'
*/
const takeQuizForm = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: takeQuiz.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SharedAccessController::takeQuiz
* @see app/Http/Controllers/SharedAccessController.php:93
* @route '/shared/quiz/{token}/take/{attempt}'
*/
takeQuizForm.get = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: takeQuiz.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SharedAccessController::takeQuiz
* @see app/Http/Controllers/SharedAccessController.php:93
* @route '/shared/quiz/{token}/take/{attempt}'
*/
takeQuizForm.head = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: takeQuiz.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

takeQuiz.form = takeQuizForm

/**
* @see \App\Http\Controllers\SharedAccessController::saveAnswer
* @see app/Http/Controllers/SharedAccessController.php:160
* @route '/shared/quiz/{token}/save-answer/{attempt}'
*/
export const saveAnswer = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: saveAnswer.url(args, options),
    method: 'post',
})

saveAnswer.definition = {
    methods: ["post"],
    url: '/shared/quiz/{token}/save-answer/{attempt}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SharedAccessController::saveAnswer
* @see app/Http/Controllers/SharedAccessController.php:160
* @route '/shared/quiz/{token}/save-answer/{attempt}'
*/
saveAnswer.url = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            token: args[0],
            attempt: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        token: args.token,
        attempt: typeof args.attempt === 'object'
        ? args.attempt.id
        : args.attempt,
    }

    return saveAnswer.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace('{attempt}', parsedArgs.attempt.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SharedAccessController::saveAnswer
* @see app/Http/Controllers/SharedAccessController.php:160
* @route '/shared/quiz/{token}/save-answer/{attempt}'
*/
saveAnswer.post = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: saveAnswer.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SharedAccessController::saveAnswer
* @see app/Http/Controllers/SharedAccessController.php:160
* @route '/shared/quiz/{token}/save-answer/{attempt}'
*/
const saveAnswerForm = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: saveAnswer.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SharedAccessController::saveAnswer
* @see app/Http/Controllers/SharedAccessController.php:160
* @route '/shared/quiz/{token}/save-answer/{attempt}'
*/
saveAnswerForm.post = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: saveAnswer.url(args, options),
    method: 'post',
})

saveAnswer.form = saveAnswerForm

/**
* @see \App\Http\Controllers\SharedAccessController::submitQuiz
* @see app/Http/Controllers/SharedAccessController.php:220
* @route '/shared/quiz/{token}/submit/{attempt}'
*/
export const submitQuiz = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submitQuiz.url(args, options),
    method: 'post',
})

submitQuiz.definition = {
    methods: ["post"],
    url: '/shared/quiz/{token}/submit/{attempt}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SharedAccessController::submitQuiz
* @see app/Http/Controllers/SharedAccessController.php:220
* @route '/shared/quiz/{token}/submit/{attempt}'
*/
submitQuiz.url = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            token: args[0],
            attempt: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        token: args.token,
        attempt: typeof args.attempt === 'object'
        ? args.attempt.id
        : args.attempt,
    }

    return submitQuiz.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace('{attempt}', parsedArgs.attempt.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SharedAccessController::submitQuiz
* @see app/Http/Controllers/SharedAccessController.php:220
* @route '/shared/quiz/{token}/submit/{attempt}'
*/
submitQuiz.post = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submitQuiz.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SharedAccessController::submitQuiz
* @see app/Http/Controllers/SharedAccessController.php:220
* @route '/shared/quiz/{token}/submit/{attempt}'
*/
const submitQuizForm = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submitQuiz.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SharedAccessController::submitQuiz
* @see app/Http/Controllers/SharedAccessController.php:220
* @route '/shared/quiz/{token}/submit/{attempt}'
*/
submitQuizForm.post = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submitQuiz.url(args, options),
    method: 'post',
})

submitQuiz.form = submitQuizForm

/**
* @see \App\Http\Controllers\SharedAccessController::results
* @see app/Http/Controllers/SharedAccessController.php:249
* @route '/shared/quiz/{token}/results/{attempt}'
*/
export const results = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: results.url(args, options),
    method: 'get',
})

results.definition = {
    methods: ["get","head"],
    url: '/shared/quiz/{token}/results/{attempt}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SharedAccessController::results
* @see app/Http/Controllers/SharedAccessController.php:249
* @route '/shared/quiz/{token}/results/{attempt}'
*/
results.url = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            token: args[0],
            attempt: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        token: args.token,
        attempt: typeof args.attempt === 'object'
        ? args.attempt.id
        : args.attempt,
    }

    return results.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace('{attempt}', parsedArgs.attempt.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SharedAccessController::results
* @see app/Http/Controllers/SharedAccessController.php:249
* @route '/shared/quiz/{token}/results/{attempt}'
*/
results.get = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: results.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SharedAccessController::results
* @see app/Http/Controllers/SharedAccessController.php:249
* @route '/shared/quiz/{token}/results/{attempt}'
*/
results.head = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: results.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SharedAccessController::results
* @see app/Http/Controllers/SharedAccessController.php:249
* @route '/shared/quiz/{token}/results/{attempt}'
*/
const resultsForm = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: results.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SharedAccessController::results
* @see app/Http/Controllers/SharedAccessController.php:249
* @route '/shared/quiz/{token}/results/{attempt}'
*/
resultsForm.get = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: results.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SharedAccessController::results
* @see app/Http/Controllers/SharedAccessController.php:249
* @route '/shared/quiz/{token}/results/{attempt}'
*/
resultsForm.head = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: results.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

results.form = resultsForm

const SharedAccessController = { access, startQuiz, takeQuiz, saveAnswer, submitQuiz, results }

export default SharedAccessController