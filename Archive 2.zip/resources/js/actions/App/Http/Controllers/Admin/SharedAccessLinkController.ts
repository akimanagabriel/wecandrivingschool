import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::index
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:15
* @route '/admin/shared-links'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/shared-links',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::index
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:15
* @route '/admin/shared-links'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::index
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:15
* @route '/admin/shared-links'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::index
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:15
* @route '/admin/shared-links'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::index
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:15
* @route '/admin/shared-links'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::index
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:15
* @route '/admin/shared-links'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::index
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:15
* @route '/admin/shared-links'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::create
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:0
* @route '/admin/shared-links/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/shared-links/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::create
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:0
* @route '/admin/shared-links/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::create
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:0
* @route '/admin/shared-links/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::create
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:0
* @route '/admin/shared-links/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::create
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:0
* @route '/admin/shared-links/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::create
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:0
* @route '/admin/shared-links/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::create
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:0
* @route '/admin/shared-links/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::store
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:44
* @route '/admin/shared-links'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/shared-links',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::store
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:44
* @route '/admin/shared-links'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::store
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:44
* @route '/admin/shared-links'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::store
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:44
* @route '/admin/shared-links'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::store
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:44
* @route '/admin/shared-links'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::edit
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:0
* @route '/admin/shared-links/{shared_link}/edit'
*/
export const edit = (args: { shared_link: string | number } | [shared_link: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/shared-links/{shared_link}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::edit
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:0
* @route '/admin/shared-links/{shared_link}/edit'
*/
edit.url = (args: { shared_link: string | number } | [shared_link: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { shared_link: args }
    }

    if (Array.isArray(args)) {
        args = {
            shared_link: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        shared_link: args.shared_link,
    }

    return edit.definition.url
            .replace('{shared_link}', parsedArgs.shared_link.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::edit
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:0
* @route '/admin/shared-links/{shared_link}/edit'
*/
edit.get = (args: { shared_link: string | number } | [shared_link: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::edit
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:0
* @route '/admin/shared-links/{shared_link}/edit'
*/
edit.head = (args: { shared_link: string | number } | [shared_link: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::edit
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:0
* @route '/admin/shared-links/{shared_link}/edit'
*/
const editForm = (args: { shared_link: string | number } | [shared_link: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::edit
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:0
* @route '/admin/shared-links/{shared_link}/edit'
*/
editForm.get = (args: { shared_link: string | number } | [shared_link: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::edit
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:0
* @route '/admin/shared-links/{shared_link}/edit'
*/
editForm.head = (args: { shared_link: string | number } | [shared_link: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::update
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:63
* @route '/admin/shared-links/{shared_link}'
*/
export const update = (args: { shared_link: string | number } | [shared_link: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/admin/shared-links/{shared_link}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::update
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:63
* @route '/admin/shared-links/{shared_link}'
*/
update.url = (args: { shared_link: string | number } | [shared_link: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { shared_link: args }
    }

    if (Array.isArray(args)) {
        args = {
            shared_link: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        shared_link: args.shared_link,
    }

    return update.definition.url
            .replace('{shared_link}', parsedArgs.shared_link.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::update
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:63
* @route '/admin/shared-links/{shared_link}'
*/
update.put = (args: { shared_link: string | number } | [shared_link: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::update
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:63
* @route '/admin/shared-links/{shared_link}'
*/
update.patch = (args: { shared_link: string | number } | [shared_link: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::update
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:63
* @route '/admin/shared-links/{shared_link}'
*/
const updateForm = (args: { shared_link: string | number } | [shared_link: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::update
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:63
* @route '/admin/shared-links/{shared_link}'
*/
updateForm.put = (args: { shared_link: string | number } | [shared_link: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::update
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:63
* @route '/admin/shared-links/{shared_link}'
*/
updateForm.patch = (args: { shared_link: string | number } | [shared_link: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::destroy
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:77
* @route '/admin/shared-links/{shared_link}'
*/
export const destroy = (args: { shared_link: string | number } | [shared_link: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/shared-links/{shared_link}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::destroy
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:77
* @route '/admin/shared-links/{shared_link}'
*/
destroy.url = (args: { shared_link: string | number } | [shared_link: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { shared_link: args }
    }

    if (Array.isArray(args)) {
        args = {
            shared_link: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        shared_link: args.shared_link,
    }

    return destroy.definition.url
            .replace('{shared_link}', parsedArgs.shared_link.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::destroy
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:77
* @route '/admin/shared-links/{shared_link}'
*/
destroy.delete = (args: { shared_link: string | number } | [shared_link: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::destroy
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:77
* @route '/admin/shared-links/{shared_link}'
*/
const destroyForm = (args: { shared_link: string | number } | [shared_link: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::destroy
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:77
* @route '/admin/shared-links/{shared_link}'
*/
destroyForm.delete = (args: { shared_link: string | number } | [shared_link: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::toggleActive
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:84
* @route '/admin/shared-links/{sharedAccessLink}/toggle-active'
*/
export const toggleActive = (args: { sharedAccessLink: number | { id: number } } | [sharedAccessLink: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleActive.url(args, options),
    method: 'post',
})

toggleActive.definition = {
    methods: ["post"],
    url: '/admin/shared-links/{sharedAccessLink}/toggle-active',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::toggleActive
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:84
* @route '/admin/shared-links/{sharedAccessLink}/toggle-active'
*/
toggleActive.url = (args: { sharedAccessLink: number | { id: number } } | [sharedAccessLink: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { sharedAccessLink: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { sharedAccessLink: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            sharedAccessLink: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        sharedAccessLink: typeof args.sharedAccessLink === 'object'
        ? args.sharedAccessLink.id
        : args.sharedAccessLink,
    }

    return toggleActive.definition.url
            .replace('{sharedAccessLink}', parsedArgs.sharedAccessLink.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::toggleActive
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:84
* @route '/admin/shared-links/{sharedAccessLink}/toggle-active'
*/
toggleActive.post = (args: { sharedAccessLink: number | { id: number } } | [sharedAccessLink: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleActive.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::toggleActive
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:84
* @route '/admin/shared-links/{sharedAccessLink}/toggle-active'
*/
const toggleActiveForm = (args: { sharedAccessLink: number | { id: number } } | [sharedAccessLink: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: toggleActive.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::toggleActive
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:84
* @route '/admin/shared-links/{sharedAccessLink}/toggle-active'
*/
toggleActiveForm.post = (args: { sharedAccessLink: number | { id: number } } | [sharedAccessLink: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: toggleActive.url(args, options),
    method: 'post',
})

toggleActive.form = toggleActiveForm

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::regenerateToken
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:91
* @route '/admin/shared-links/{sharedAccessLink}/regenerate-token'
*/
export const regenerateToken = (args: { sharedAccessLink: number | { id: number } } | [sharedAccessLink: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: regenerateToken.url(args, options),
    method: 'post',
})

regenerateToken.definition = {
    methods: ["post"],
    url: '/admin/shared-links/{sharedAccessLink}/regenerate-token',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::regenerateToken
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:91
* @route '/admin/shared-links/{sharedAccessLink}/regenerate-token'
*/
regenerateToken.url = (args: { sharedAccessLink: number | { id: number } } | [sharedAccessLink: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { sharedAccessLink: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { sharedAccessLink: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            sharedAccessLink: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        sharedAccessLink: typeof args.sharedAccessLink === 'object'
        ? args.sharedAccessLink.id
        : args.sharedAccessLink,
    }

    return regenerateToken.definition.url
            .replace('{sharedAccessLink}', parsedArgs.sharedAccessLink.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::regenerateToken
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:91
* @route '/admin/shared-links/{sharedAccessLink}/regenerate-token'
*/
regenerateToken.post = (args: { sharedAccessLink: number | { id: number } } | [sharedAccessLink: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: regenerateToken.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::regenerateToken
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:91
* @route '/admin/shared-links/{sharedAccessLink}/regenerate-token'
*/
const regenerateTokenForm = (args: { sharedAccessLink: number | { id: number } } | [sharedAccessLink: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: regenerateToken.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::regenerateToken
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:91
* @route '/admin/shared-links/{sharedAccessLink}/regenerate-token'
*/
regenerateTokenForm.post = (args: { sharedAccessLink: number | { id: number } } | [sharedAccessLink: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: regenerateToken.url(args, options),
    method: 'post',
})

regenerateToken.form = regenerateTokenForm

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::stats
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:99
* @route '/admin/shared-links/{sharedAccessLink}/stats'
*/
export const stats = (args: { sharedAccessLink: number | { id: number } } | [sharedAccessLink: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stats.url(args, options),
    method: 'get',
})

stats.definition = {
    methods: ["get","head"],
    url: '/admin/shared-links/{sharedAccessLink}/stats',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::stats
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:99
* @route '/admin/shared-links/{sharedAccessLink}/stats'
*/
stats.url = (args: { sharedAccessLink: number | { id: number } } | [sharedAccessLink: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { sharedAccessLink: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { sharedAccessLink: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            sharedAccessLink: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        sharedAccessLink: typeof args.sharedAccessLink === 'object'
        ? args.sharedAccessLink.id
        : args.sharedAccessLink,
    }

    return stats.definition.url
            .replace('{sharedAccessLink}', parsedArgs.sharedAccessLink.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::stats
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:99
* @route '/admin/shared-links/{sharedAccessLink}/stats'
*/
stats.get = (args: { sharedAccessLink: number | { id: number } } | [sharedAccessLink: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stats.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::stats
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:99
* @route '/admin/shared-links/{sharedAccessLink}/stats'
*/
stats.head = (args: { sharedAccessLink: number | { id: number } } | [sharedAccessLink: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: stats.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::stats
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:99
* @route '/admin/shared-links/{sharedAccessLink}/stats'
*/
const statsForm = (args: { sharedAccessLink: number | { id: number } } | [sharedAccessLink: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: stats.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::stats
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:99
* @route '/admin/shared-links/{sharedAccessLink}/stats'
*/
statsForm.get = (args: { sharedAccessLink: number | { id: number } } | [sharedAccessLink: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: stats.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\SharedAccessLinkController::stats
* @see app/Http/Controllers/Admin/SharedAccessLinkController.php:99
* @route '/admin/shared-links/{sharedAccessLink}/stats'
*/
statsForm.head = (args: { sharedAccessLink: number | { id: number } } | [sharedAccessLink: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: stats.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

stats.form = statsForm

const SharedAccessLinkController = { index, create, store, edit, update, destroy, toggleActive, regenerateToken, stats }

export default SharedAccessLinkController