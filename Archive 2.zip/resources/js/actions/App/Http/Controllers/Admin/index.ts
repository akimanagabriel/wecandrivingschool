import DashboardController from './DashboardController'
import QuestionController from './QuestionController'
import UserController from './UserController'
import PaymentController from './PaymentController'
import PricingPlanController from './PricingPlanController'
import SharedAccessLinkController from './SharedAccessLinkController'

const Admin = {
    DashboardController: Object.assign(DashboardController, DashboardController),
    QuestionController: Object.assign(QuestionController, QuestionController),
    UserController: Object.assign(UserController, UserController),
    PaymentController: Object.assign(PaymentController, PaymentController),
    PricingPlanController: Object.assign(PricingPlanController, PricingPlanController),
    SharedAccessLinkController: Object.assign(SharedAccessLinkController, SharedAccessLinkController),
}

export default Admin