import WelcomeController from './WelcomeController'
import Settings from './Settings'
import StudentDashboardController from './StudentDashboardController'
import PaymentController from './PaymentController'
import QuizController from './QuizController'
import Admin from './Admin'
import SharedAccessController from './SharedAccessController'

const Controllers = {
    WelcomeController: Object.assign(WelcomeController, WelcomeController),
    Settings: Object.assign(Settings, Settings),
    StudentDashboardController: Object.assign(StudentDashboardController, StudentDashboardController),
    PaymentController: Object.assign(PaymentController, PaymentController),
    QuizController: Object.assign(QuizController, QuizController),
    Admin: Object.assign(Admin, Admin),
    SharedAccessController: Object.assign(SharedAccessController, SharedAccessController),
}

export default Controllers