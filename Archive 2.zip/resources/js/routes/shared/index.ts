import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import quiz from './quiz'
/**
* @see \App\Http\Controllers\SharedAccessController::access
* @see app/Http/Controllers/SharedAccessController.php:19
* @route '/shared/access/{token}'
*/
export const access = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: access.url(args, options),
    method: 'get',
})

access.definition = {
    methods: ["get","head"],
    url: '/shared/access/{token}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SharedAccessController::access
* @see app/Http/Controllers/SharedAccessController.php:19
* @route '/shared/access/{token}'
*/
access.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    if (Array.isArray(args)) {
        args = {
            token: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        token: args.token,
    }

    return access.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SharedAccessController::access
* @see app/Http/Controllers/SharedAccessController.php:19
* @route '/shared/access/{token}'
*/
access.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: access.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SharedAccessController::access
* @see app/Http/Controllers/SharedAccessController.php:19
* @route '/shared/access/{token}'
*/
access.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: access.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SharedAccessController::access
* @see app/Http/Controllers/SharedAccessController.php:19
* @route '/shared/access/{token}'
*/
const accessForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: access.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SharedAccessController::access
* @see app/Http/Controllers/SharedAccessController.php:19
* @route '/shared/access/{token}'
*/
accessForm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: access.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SharedAccessController::access
* @see app/Http/Controllers/SharedAccessController.php:19
* @route '/shared/access/{token}'
*/
accessForm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: access.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

access.form = accessForm

const shared = {
    access: Object.assign(access, access),
    quiz: Object.assign(quiz, quiz),
}

export default shared