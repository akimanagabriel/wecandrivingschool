import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\SharedAccessController::start
* @see app/Http/Controllers/SharedAccessController.php:31
* @route '/shared/quiz/{token}/start'
*/
export const start = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: start.url(args, options),
    method: 'get',
})

start.definition = {
    methods: ["get","head"],
    url: '/shared/quiz/{token}/start',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SharedAccessController::start
* @see app/Http/Controllers/SharedAccessController.php:31
* @route '/shared/quiz/{token}/start'
*/
start.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    if (Array.isArray(args)) {
        args = {
            token: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        token: args.token,
    }

    return start.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SharedAccessController::start
* @see app/Http/Controllers/SharedAccessController.php:31
* @route '/shared/quiz/{token}/start'
*/
start.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: start.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SharedAccessController::start
* @see app/Http/Controllers/SharedAccessController.php:31
* @route '/shared/quiz/{token}/start'
*/
start.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: start.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SharedAccessController::start
* @see app/Http/Controllers/SharedAccessController.php:31
* @route '/shared/quiz/{token}/start'
*/
const startForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: start.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SharedAccessController::start
* @see app/Http/Controllers/SharedAccessController.php:31
* @route '/shared/quiz/{token}/start'
*/
startForm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: start.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SharedAccessController::start
* @see app/Http/Controllers/SharedAccessController.php:31
* @route '/shared/quiz/{token}/start'
*/
startForm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: start.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

start.form = startForm

/**
* @see \App\Http\Controllers\SharedAccessController::take
* @see app/Http/Controllers/SharedAccessController.php:93
* @route '/shared/quiz/{token}/take/{attempt}'
*/
export const take = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: take.url(args, options),
    method: 'get',
})

take.definition = {
    methods: ["get","head"],
    url: '/shared/quiz/{token}/take/{attempt}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SharedAccessController::take
* @see app/Http/Controllers/SharedAccessController.php:93
* @route '/shared/quiz/{token}/take/{attempt}'
*/
take.url = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            token: args[0],
            attempt: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        token: args.token,
        attempt: typeof args.attempt === 'object'
        ? args.attempt.id
        : args.attempt,
    }

    return take.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace('{attempt}', parsedArgs.attempt.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SharedAccessController::take
* @see app/Http/Controllers/SharedAccessController.php:93
* @route '/shared/quiz/{token}/take/{attempt}'
*/
take.get = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: take.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SharedAccessController::take
* @see app/Http/Controllers/SharedAccessController.php:93
* @route '/shared/quiz/{token}/take/{attempt}'
*/
take.head = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: take.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SharedAccessController::take
* @see app/Http/Controllers/SharedAccessController.php:93
* @route '/shared/quiz/{token}/take/{attempt}'
*/
const takeForm = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: take.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SharedAccessController::take
* @see app/Http/Controllers/SharedAccessController.php:93
* @route '/shared/quiz/{token}/take/{attempt}'
*/
takeForm.get = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: take.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SharedAccessController::take
* @see app/Http/Controllers/SharedAccessController.php:93
* @route '/shared/quiz/{token}/take/{attempt}'
*/
takeForm.head = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: take.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

take.form = takeForm

/**
* @see \App\Http\Controllers\SharedAccessController::saveAnswer
* @see app/Http/Controllers/SharedAccessController.php:160
* @route '/shared/quiz/{token}/save-answer/{attempt}'
*/
export const saveAnswer = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: saveAnswer.url(args, options),
    method: 'post',
})

saveAnswer.definition = {
    methods: ["post"],
    url: '/shared/quiz/{token}/save-answer/{attempt}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SharedAccessController::saveAnswer
* @see app/Http/Controllers/SharedAccessController.php:160
* @route '/shared/quiz/{token}/save-answer/{attempt}'
*/
saveAnswer.url = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            token: args[0],
            attempt: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        token: args.token,
        attempt: typeof args.attempt === 'object'
        ? args.attempt.id
        : args.attempt,
    }

    return saveAnswer.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace('{attempt}', parsedArgs.attempt.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SharedAccessController::saveAnswer
* @see app/Http/Controllers/SharedAccessController.php:160
* @route '/shared/quiz/{token}/save-answer/{attempt}'
*/
saveAnswer.post = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: saveAnswer.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SharedAccessController::saveAnswer
* @see app/Http/Controllers/SharedAccessController.php:160
* @route '/shared/quiz/{token}/save-answer/{attempt}'
*/
const saveAnswerForm = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: saveAnswer.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SharedAccessController::saveAnswer
* @see app/Http/Controllers/SharedAccessController.php:160
* @route '/shared/quiz/{token}/save-answer/{attempt}'
*/
saveAnswerForm.post = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: saveAnswer.url(args, options),
    method: 'post',
})

saveAnswer.form = saveAnswerForm

/**
* @see \App\Http\Controllers\SharedAccessController::submit
* @see app/Http/Controllers/SharedAccessController.php:220
* @route '/shared/quiz/{token}/submit/{attempt}'
*/
export const submit = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(args, options),
    method: 'post',
})

submit.definition = {
    methods: ["post"],
    url: '/shared/quiz/{token}/submit/{attempt}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SharedAccessController::submit
* @see app/Http/Controllers/SharedAccessController.php:220
* @route '/shared/quiz/{token}/submit/{attempt}'
*/
submit.url = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            token: args[0],
            attempt: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        token: args.token,
        attempt: typeof args.attempt === 'object'
        ? args.attempt.id
        : args.attempt,
    }

    return submit.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace('{attempt}', parsedArgs.attempt.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SharedAccessController::submit
* @see app/Http/Controllers/SharedAccessController.php:220
* @route '/shared/quiz/{token}/submit/{attempt}'
*/
submit.post = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SharedAccessController::submit
* @see app/Http/Controllers/SharedAccessController.php:220
* @route '/shared/quiz/{token}/submit/{attempt}'
*/
const submitForm = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submit.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\SharedAccessController::submit
* @see app/Http/Controllers/SharedAccessController.php:220
* @route '/shared/quiz/{token}/submit/{attempt}'
*/
submitForm.post = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submit.url(args, options),
    method: 'post',
})

submit.form = submitForm

/**
* @see \App\Http\Controllers\SharedAccessController::results
* @see app/Http/Controllers/SharedAccessController.php:249
* @route '/shared/quiz/{token}/results/{attempt}'
*/
export const results = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: results.url(args, options),
    method: 'get',
})

results.definition = {
    methods: ["get","head"],
    url: '/shared/quiz/{token}/results/{attempt}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SharedAccessController::results
* @see app/Http/Controllers/SharedAccessController.php:249
* @route '/shared/quiz/{token}/results/{attempt}'
*/
results.url = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            token: args[0],
            attempt: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        token: args.token,
        attempt: typeof args.attempt === 'object'
        ? args.attempt.id
        : args.attempt,
    }

    return results.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace('{attempt}', parsedArgs.attempt.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SharedAccessController::results
* @see app/Http/Controllers/SharedAccessController.php:249
* @route '/shared/quiz/{token}/results/{attempt}'
*/
results.get = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: results.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SharedAccessController::results
* @see app/Http/Controllers/SharedAccessController.php:249
* @route '/shared/quiz/{token}/results/{attempt}'
*/
results.head = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: results.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\SharedAccessController::results
* @see app/Http/Controllers/SharedAccessController.php:249
* @route '/shared/quiz/{token}/results/{attempt}'
*/
const resultsForm = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: results.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SharedAccessController::results
* @see app/Http/Controllers/SharedAccessController.php:249
* @route '/shared/quiz/{token}/results/{attempt}'
*/
resultsForm.get = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: results.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\SharedAccessController::results
* @see app/Http/Controllers/SharedAccessController.php:249
* @route '/shared/quiz/{token}/results/{attempt}'
*/
resultsForm.head = (args: { token: string | number, attempt: number | { id: number } } | [token: string | number, attempt: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: results.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

results.form = resultsForm

const quiz = {
    start: Object.assign(start, start),
    take: Object.assign(take, take),
    saveAnswer: Object.assign(saveAnswer, saveAnswer),
    submit: Object.assign(submit, submit),
    results: Object.assign(results, results),
}

export default quiz