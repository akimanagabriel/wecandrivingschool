<?php echo e($slot); ?>

<?php /**PATH /Users/toptrust/Documents/Projects/wecan-driving-school/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>