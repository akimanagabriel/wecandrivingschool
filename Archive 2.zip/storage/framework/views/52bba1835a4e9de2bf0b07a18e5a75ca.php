<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/toptrust/Documents/Projects/wecan-driving-school/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php ENDPATH**/ ?>